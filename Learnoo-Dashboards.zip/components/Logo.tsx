import React from 'react';

interface LogoProps {
  className?: string;
  width?: number | string;
  height?: number | string;
}

export default function Logo({ className, width = 40, height = 39 }: LogoProps) {
  return (
    <svg 
      width={width} 
      height={height} 
      viewBox="0 0 80 77" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <mask id="path-1-inside-1_463_1169" fill="white">
        <path d="M0 0H80V77H0V0Z"/>
      </mask>
      <path 
        d="M80 77V76H0V77V78H80V77Z" 
        fill="white" 
        fillOpacity="0.1" 
        mask="url(#path-1-inside-1_463_1169)"
      />
      <path 
        d="M26.4179 30.7214L14.5596 40.596C26.178 45.3543 32.3101 49.6582 36.4964 59.4254C39.1871 53.3477 42.4686 49.2848 48.5983 43.8895C54.5776 38.6277 60.5557 35.4428 65.4404 35.1112L49.9818 16.5752C45.3096 18.1808 40.6016 21.9753 39.193 31.7783C38.675 35.3843 38.2763 40.0389 37.7176 42.9089C37.7176 42.9113 37.7176 42.9125 37.7176 42.9149C37.7116 42.9746 37.7033 43.0342 37.6961 43.0938C37.424 45.1539 36.5836 46.5233 36.5478 46.5818L36.1157 46.3122C36.1228 46.2991 36.9405 44.9643 37.1936 43.0056C37.2497 42.5797 37.2747 42.1562 37.2712 41.7411C36.2458 36.1895 32.0881 30.7047 26.4203 30.7214H26.4179Z" 
        fill="currentColor"
      />
    </svg>
  );
}
